import csv
import getopt
import sys     # sys.argv needed
# argparse
# getopt
# fire

inp = ''     # input file name
outp = ''    # output file name
indlm = '|'  # delimiter
inqt = ''    # "\'"

def changef(inf, outf, ind, inq):
    #print(f'[changef]: {inf}, {outf}, "{ind}", "{inq}"')
    with open(inf, newline='') as f:
        lines = csv.reader(f, delimiter=ind) #, quotechar=inqt)
        with open(outf, 'w', newline='') as o:
            csvwr = csv.writer(o,delimiter=',')
            for row in lines:
               csvwr.writerow(row)


if __name__ == '__main__':
    
    optlist, args = getopt.gnu_getopt(sys.argv[1:], '', ['in-delimiter=', 'in-quote='])
   
    # print(optlist)
    for a in optlist:
        if a[0] == '--in-delimeter':
            indlm = a[1]
        elif a[0] == '--in-quote':
            inqt = a[1]
   
    # print(args)
    inp = args[0]
    outp = args[1]
    
    changef(inp, outp, indlm, inqt)

    

    